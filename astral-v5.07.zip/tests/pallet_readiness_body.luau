local Pallet=requireModule('PalletRagdoll')
local function harness(mode)
    local now=0;local destroys,releases=0,0
    local pre,post=signal(),signal()
    local readiness={}
    local context={RunService={PreSimulation=pre,PostSimulation=post},Clock=function()return now end,
        Owned=function()return true end,Grab=function()end,SpawnThread=function()end,
        KickMode=function()return mode or 'Faster'end,ContactRate=155,
        CanContact=function(character)return readiness[character]~=false,'Capture in progress'end,
        ParkPosition=function()return Vector3.new(0,1000,0)end,
        Destroy=function()destroys+=1 end,ReleaseSupply=function()releases+=1 end}
    local p=Pallet.Install(context)
    -- The tests bypass appearance and preparation only; Step/Place/Park and
    -- cancellation are the actual module methods operating on the test rig.
    p.Style=function()end;p.Restore=function()end
    local model={Parent={}}
    local sound={Parent=model,Anchored=false,IsA=function(_,class)return class=='BasePart'end,
        IsDescendantOf=function(_,parent)return parent==model end}
    p.Model,p.Sound=model,sound
    local h={P=p,Readiness=readiness,Sound=sound,Model=model}
    function h:Character(name)
        local c={Parent={},Name=name}
        local root={Parent=c,Position=Vector3.new(1,2,3),Anchored=false,IsA=function(_,class)return class=='BasePart'end}
        local receiver={Parent=root,Name='RagdollTouchedHitbox',Position=Vector3.new(20,30,40),CanTouch=true,
            IsA=function(_,class)return class=='BasePart'end}
        function root:FindFirstChild(name)if name=='RagdollTouchedHitbox'then return receiver end end
        local hum={Parent=c,Health=100}
        function c:FindFirstChild(name)if name=='HumanoidRootPart'then return root end end
        function c:FindFirstChildOfClass(name)if name=='Humanoid'then return hum end end
        return c,root,receiver
    end
    function h:Pre()now+=1/60;pre:Fire(1/60);assert(not p.LastError,p.LastError)end
    function h:Post()post:Fire(1/60);assert(not p.LastError,p.LastError)end
    function h:Counts()return destroys,releases end
    return h
end
for _,mode in ipairs({'Faster','Normal','Super Fast'})do
    local h=harness(mode);local p=h.P
    local c,root,receiver=h:Character(mode)
    local entry=p:Request(c,function()return true end,true,false)
    local segments=mode=='Normal'and 8 or mode=='Faster'and 2 or 1
    for _=1,segments do h:Pre();h:Post()end
    assert(h.Sound.CFrame.Position.X==receiver.Position.X and h.Sound.CFrame.Position.Y==receiver.Position.Y and h.Sound.CFrame.Position.Z==receiver.Position.Z,
        'every profile must reach the touch receiver, not HRP')
    assert(p.Passes==1,'stage counts must remain unchanged')
    h.Readiness[c]=false
    h:Pre()
    assert(p.Entries[c]==entry and p.Model==h.Model and p.Sound==h.Sound,'pause must preserve entry and pallet')
    assert(entry.Stage==0 and entry.Phase=='down'and p.Active==nil,'pause must reset/requeue active trajectory')
    assert(h.Sound.CFrame.Position.Y==1000,'pause must park the pallet')
    local a,b=h:Counts();assert(a==0 and b==0,'pause must not destroy/release supply')
    local attempts=p.StrikeAttempts
    h.Readiness[c]=true
    h:Pre() -- no solver callback between park and resume
    assert(p.StrikeAttempts==attempts,'park must get an actual physics exit before resume')
    h:Post();h:Pre()
    assert(p.StrikeAttempts==attempts+1 and p.Entries[c]==entry,'same entry must resume after exit')
    p:Cancel(c)
    a,b=h:Counts();assert(a==1 and b==1,'actual cancellation must destroy and release exactly once')
    p:Cancel(c);a,b=h:Counts();assert(a==1 and b==1)
    print('PASS Pallet',mode,'receiver trajectory, pause/reuse, physics exit and cleanup')
end
do
    local h=harness('Super Fast');local p=h.P
    local first=h:Character('blocked');local second=h:Character('ready')
    h.Readiness[first]=false
    p:Request(first,function()return true end,true,false)
    local eligible=p:Request(second,function()return true end,true,false)
    h:Pre()
    assert(p.Active==eligible and p.StrikeAttempts==1,'blocked queue head must not starve a ready target')
    assert(p.Entries[first]and p.Entries[second])
    print('PASS Pallet readiness queue fairness')
end
do
    local h=harness();local p=h.P;local c=h:Character('invalid');local valid=true
    p:Request(c,function()return valid end,true,false)
    h:Pre();h:Post();valid=false;h:Pre()
    local a,b=h:Counts();assert(not p.Entries[c]and a==1 and b==1,'lifetime invalidation must still clean up')
    print('PASS Pallet lifetime invalidation cleanup')
end
