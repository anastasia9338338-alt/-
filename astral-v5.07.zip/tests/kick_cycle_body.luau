local Handoff=requireModule('KickHandoff')
local Loop=requireModule('KickLoop')
for _,fps in ipairs({30,60,100,144,240})do
    local now,frame,marker=0,0,true
    local mode='Super Fast'
    local events={}
    local root={Parent={}}
    local session={Root=root,Player={},Character={},CaptureAcknowledged=true,HadPhysicalHold=true,ReleaseRetryAt=0}
    local ctx={Clock=function()return now end,SourceMode=function()return mode end,PingSeconds=function()return .05 end,
        Owned=function()return marker end,MarkerOwned=function()return marker end,
        Grab=function()marker=true;table.insert(events,{'G',frame,now})end,
        Release=function()marker=false;table.insert(events,{'R',frame,now})end,
        ShadowSource=true,LowLatency=true,RecoverLostHold=true,Acquire=function()end}
    local loop=setmetatable({Context=ctx,Frame=0,Calls=0,Released=0,Sessions={},Valid=function()return true end},Loop)
    local nextAt=0
    for i=0,math.floor(fps*2)do
        now=i/fps
        if now+1e-7>=nextAt then
            frame+=1;loop.Frame=frame
            nextAt=now-nextAt>=1/60 and now+1/60 or nextAt+1/60
            loop:SourceCycle(session,now,nil,true)
        end
    end
    assert(#events>=math.floor(math.min(fps,60)*1.7),'fast modes gained an unintended fixed delay')
    for i,event in ipairs(events)do
        assert(event[1]==(i%2==1 and 'G'or'R'),'operations must alternate')
        if i>1 then assert(event[2]>events[i-1][2],'no grab/release may share a solver tick')end
    end
    -- Recovery must suppress the source release phase rather than destroy contacts.
    local cancel=0;ctx.CancelRagdoll=function()cancel+=1 end
    session.HadPhysicalHold=false;events={};loop:ShadowCycle(session,now,nil,true)
    assert(#events==0,'initial hold must settle before refreshing')
    session.HadPhysicalHold=true;session.RecoveringHold=true
    session.RecoveryGrabAt=0;session.Acquiring=false;ctx.NetworkOwned=function()return true end
    loop:SourceCycle(session,now,nil,true)
    assert(#events==1 and events[1][1]=='G'and session.Handoff==nil,'recovery must take priority over shadow cycle')
    assert(cancel==0,'temporary recovery must not cancel pallet lifetime')
    print('PASS Kick alternate solver phases and recovery',fps,'FPS')
end
-- Lost marker acknowledgements wait for a bounded handoff deadline.
do
    local s={};Handoff.Grabbed(s,1,0,.1,false)
    assert(not Handoff.CanRelease(s,1,.5,false),'must wait a later frame')
    assert(not Handoff.CanRelease(s,2,.06,false),'missing acknowledgement should not release immediately')
    assert(Handoff.CanRelease(s,3,.21,false),'missing acknowledgement must not stall forever')
    Handoff.Released(s,3,.21,.1,false)
    assert(not Handoff.CanGrab(s,4,.27,true))
    assert(Handoff.CanGrab(s,5,.32,true))
end
-- Disabling a custom interval must clear the outstanding timing gate.
do
    local now=0;local loop=setmetatable({Context={IntervalSeconds=function()return nil end}},Loop)
    local session={IntervalSeconds=1}
    Handoff.Grabbed(session,1,0,0,false,1)
    assert(not Handoff.CanRelease(session,2,.1,true))
    loop:IntervalPeriod(session,.1)
    assert(Handoff.CanRelease(session,2,.1,true))
end
print('PASS Kick acknowledgement deadlines and interval cancellation')
