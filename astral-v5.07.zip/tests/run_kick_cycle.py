from pathlib import Path
import subprocess
import os
root=Path(__file__).resolve().parents[1]
parts=['local factories={}\nlocal cache={}\nlocal function requireModule(name)\n if not cache[name]then cache[name]=factories[name](requireModule)end\n return cache[name]\nend\n']
for name in ('KickHandoff','SuperFastProfile','KickLoop'):
 parts.append('factories.'+name+'=function(...)\n'+(root/'modules'/f'{name}.lua').read_text()+'\nend\n')
parts.append((root/'tests/kick_cycle_body.luau').read_text())
p=root/'tests/kick_cycle.generated.luau';p.write_text('\n'.join(parts))
subprocess.run([os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau')),str(p)],check=True)
