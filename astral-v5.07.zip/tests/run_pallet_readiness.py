from pathlib import Path
import subprocess
import os

root=Path(__file__).resolve().parents[1]
parts=[(root/'tests/pallet_readiness_prelude.luau').read_text()]
for name in ('PalletOwnership','SuperFastProfile','PalletReaction','PalletRagdoll'):
    source=(root/'modules'/f'{name}.lua').read_text()
    parts.append(f'factories.{name}=function(...)\n{source}\nend\n')
parts.append((root/'tests/pallet_readiness_body.luau').read_text())
path=root/'tests/pallet_readiness.generated.luau'
path.write_text('\n'.join(parts))
cli=os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau'))
subprocess.run([str(cli),str(path)],check=True)
