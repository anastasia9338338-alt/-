-- Deterministic mock regression checks; no game/remotes are loaded.
Color3={fromRGB=function(...)return {...}end}
local Vector={};Vector.__index=Vector
function Vector.__div(v,n)return setmetatable({X=v.X/n,Y=v.Y/n},Vector)end
Vector2={new=function(x,y)return setmetatable({X=x,Y=y},Vector)end,zero=setmetatable({X=0,Y=0},Vector)}
UDim2={fromOffset=function(x,y)return{X=x,Y=y}end}
local function node(name,kind,parent)
 local v={Name=name,Kind=kind or 'Frame',Parent=parent,Children={},Visible=true,AbsoluteSize=Vector2.new(600,400)}
 function v:IsA(class)return self.Kind==class or class=='GuiObject'and(self.Kind=='Frame'or self.Kind=='TextLabel'or self.Kind=='TextButton')end
 function v:IsDescendantOf(ancestor)local n=self.Parent;while n do if n==ancestor then return true end;n=n.Parent end;return false end
 function v:GetChildren()return self.Children end
 function v:FindFirstChild(name,recursive)for _,c in ipairs(self.Children)do if c.Name==name then return c end end;if recursive then for _,c in ipairs(self.Children)do local r=c:FindFirstChild(name,true);if r then return r end end end end
 function v:FindFirstChildWhichIsA()return nil end
 if parent then table.insert(parent.Children,v)end
 return v
end
