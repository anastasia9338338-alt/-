from pathlib import Path
import subprocess
import os

root=Path(__file__).resolve().parents[1]
parts=[(root/'tests/shop_prelude.luau').read_text()]
source=(root/'modules/ShopQuickSpawn.lua').read_text()
parts.append(f'local Quick=(function()\n{source}\nend)()')
source=(root/'modules/GameShopStyle.lua').read_text()
parts.append(f'local Shop=(function(...)\n{source}\nend)(function(name)if name=="ShopQuickSpawn"then return Quick end;return {{}}end)')
parts.append((root/'tests/shop_body.luau').read_text())
path=root/'tests/shop.generated.luau'
path.write_text('\n'.join(parts))
cli=os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau'))
subprocess.run([str(cli),str(path)],check=True)
