
local passed=0
local function check(label,condition)assert(condition,label);passed+=1;print('PASS '..label)end
-- Ancestor-local invalidation keeps the unrelated page's snapshot.
local root=node('Menu');local a=node('A',nil,root);local b=node('B',nil,root)
local s=setmetatable({Pages={{Node=a}},TreeVersion=0,Queue=function()end},Shop)
local before=s:Descendants(b);s:Descendants(root)
local child=node('NewCell',nil,a);s:Invalidate(child)
local scans=s.TreeScans
check('unrelated page cache survives GUI insertion',s:Descendants(b)==before and s.TreeScans==scans)
check('ancestor cache reflects inserted GUI',#s:Descendants(root)==3)
local version=s.TreeVersion;s:Invalidate(node('Mesh','BasePart',child))
check('preview physics parts do not invalidate GUI',s.TreeVersion==version)
local world=node('Preview','WorldModel',a);local previewLabel=node('Label','TextLabel',world);s:Invalidate(previewLabel)
check('GUI nested inside preview models does not invalidate shop',s.TreeVersion==version)
local controls={};local cached={Node=b,Controls=controls,ControlsSharedVersion=0}
s.TreeVersion+=1
check('unrelated tree version preserves cached controls',s:Controls(cached)==controls)

-- Discovery skips pages whose structure is unchanged and pins native panel size.
local menu=node('Menu');local contents=node('TabContents',nil,menu)
local settings=node('Settings',nil,contents);local toys=node('Toys',nil,contents)
local d=setmetatable({Pages={},Menu=menu,Contents=contents,Context={},CollectionGrid=function(self)self.Scans=(self.Scans or 0)+1;return nil end,Watch=function()end,Write=function(_,obj,key,value)obj[key]=value end},Shop)
d:Discover();local initial=d.Scans;d:Discover()
check('unchanged pages avoid rediscovery',d.Scans==initial)
d.Pages[1].DiscoveryDirty=true;d:Discover()
check('only dirty page rediscovers grid',d.Scans==initial+1)
check('settings native size pinned before compact resize',d.Pages[1].NativeSize.X==600 and settings.Size.X==600)
-- Cell styling is bounded and cached; changing tab invalidates unfinished work.
local pending={};local heartbeat={Callbacks={}}
function heartbeat:Connect(fn)local c={Live=true,Fn=fn};function c:Disconnect()self.Live=false end;table.insert(self.Callbacks,c);return c end
local function tick()local callbacks=heartbeat.Callbacks;heartbeat.Callbacks={};for _,c in ipairs(callbacks)do if c.Live then c.Fn()end end end
local function flush()local q=pending;pending={};for _,fn in ipairs(q)do fn()end end
local page=node('Toys');local record={Node=page,Styled=true};local cells={}
for i=1,30 do cells[i]=node('Cell'..i,nil,page)end
local w=setmetatable({Enabled=true,Current=record,CellStyles={},Context={Defer=function(fn)table.insert(pending,fn)end,RunService={Heartbeat=heartbeat}},StyleCell=function(self,cell,plan,height)self.Writes=(self.Writes or 0)+1;self.CellStyles[cell]={Width=plan.Cell,Height=height}end},Shop)
w:QueueCells(record,cells,{Cell=30},30,false);flush()
check('first styling batch capped at twelve cells',w.Writes<=12 and w.Writes>0)
for i=1,40 do tick()end
check('all queued cells eventually styled',w.Writes==30 and w.CellWork==nil)
w:QueueCells(record,cells,{Cell=30},30,false);flush()
check('unchanged cells are not rewritten',w.Writes==30)
w:QueueCells(record,cells,{Cell=31},31,false);flush();w.Current={};tick()
check('switching tabs cancels and invalidates unfinished layout',w.CellWork==nil and record.Styled==nil)
-- Exception cleanup restores application flags (native changes remain observable).
w.Current=record;w.StyleCell=function()error('mock failure')end
w:QueueCells(record,cells,{Cell=32},32,false);flush()
check('cell failure restores observer state',w.Applying==nil and not w.ItemStyling and w.LastError:find('mock failure',1,true)~=nil)
-- Unchanged quick page returns before any Instance allocation.
local q=setmetatable({Host={},RenderRevision=7,Choosing=false,LastRender={Width=346,Height=274,Revision=7,Choosing=false}},Quick)
q:Render({Width=346,Height=274})
check('unchanged quick page retains existing rows',q.Rendering==nil)
print('SHOP CHECKS '..passed..' passed')
