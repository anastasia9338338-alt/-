"""Verify the distributed bundle using Luau 0.747; never execute the game bundle."""
from pathlib import Path
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

parser=argparse.ArgumentParser()
parser.add_argument('--luau',required=True,help='Path to Luau 0.747 interpreter')
parser.add_argument('--compile',required=True,help='Path to Luau 0.747 compiler')
parser.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parents[1]/'astral.lua')
args=parser.parse_args()
luau=str(Path(args.luau).resolve())
compiler=str(Path(args.compile).resolve())
source=args.bundle.read_text(encoding='utf-8')
modules={m[1]:m[2] for m in re.finditer(r'^sources\.(\w+) = \[========\[\n(.*?)^\]========\]',source,re.M|re.S)}
assert modules and 'GucciSeatTiming' in modules
missing=set(re.findall(r'requireModule\([\"\'](\w+)[\"\']\)',source))-modules.keys()
assert not missing,missing
with tempfile.TemporaryDirectory(prefix='astral-verify-')as tmp:
    root=Path(tmp)/'astral'
    (root/'modules').mkdir(parents=True)
    shutil.copytree(Path(__file__).resolve().parent,root/'tests',ignore=shutil.ignore_patterns('*.generated.luau','.*generated.luau','__pycache__'))
    count=0
    for name,body in modules.items():
        path=root/'modules'/f'{name}.lua'
        path.write_text(body,encoding='utf-8')
        if name=='Notices':continue # License text, not executable Lua.
        result=subprocess.run([compiler,'--null',str(path)],capture_output=True,text=True)
        if result.returncode:raise RuntimeError(name+' compile failed: '+result.stderr)
        count+=1
    result=subprocess.run([compiler,'--null',str(args.bundle.resolve())],capture_output=True,text=True)
    if result.returncode:raise RuntimeError('Bundle compile failed: '+result.stderr)
    print(f'PASS bundle + {count} executable module compilations; all literal dependencies present',flush=True)
    env=dict(os.environ,LUAU_BIN=luau)
    for runner in ['run_kick_restore.py','run_ragdoll_cadence.py','run_shop.py','run_spawn_toy.py']:
        subprocess.run([sys.executable,str(root/'tests'/runner)],env=env,check=True)
    subprocess.run([luau,str(root/'tests/gucci_seat_timing.luau')],check=True)
print('PASS ALL: isolated regressions; Roblox/server execution not performed')
