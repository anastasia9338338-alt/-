local passed=0
local function check(name,ok)assert(ok,name);passed+=1;print('PASS '..name)end
local function signal()
 local s={Listeners={}}
 function s:Connect(fn)
  local c={Live=true,Fn=fn};function c:Disconnect()self.Live=false end
  self.Listeners[#self.Listeners+1]=c;return c
 end
 function s:Fire(...)for _,c in ipairs(self.Listeners)do if c.Live then c.Fn(...)end end end
 return s
end
local function node(name,kind,parent)
 local obj={Name=name,Class=kind,Parent=parent,Children={},ChildAdded=signal()}
 function obj:IsA(t)return t==self.Class or t=='BasePart'and self.Class=='Part'end
 function obj:IsDescendantOf(ancestor)local v=self.Parent;while v do if v==ancestor then return true end;v=v.Parent end;return false end
 function obj:FindFirstChild(n)for _,v in ipairs(self.Children)do if v.Name==n and v.Parent==self then return v end end end
 function obj:FindFirstChildOfClass(n)for _,v in ipairs(self.Children)do if v:IsA(n)and v.Parent==self then return v end end end
 function obj:WaitForChild(n)return self:FindFirstChild(n)end
 function obj:GetPivot()return self.CFrame end
 function obj:PivotTo(frame)self.CFrame=frame end
 if parent then parent.Children[#parent.Children+1]=obj;parent.ChildAdded:Fire(obj)end
 return obj
end
local now,enabled,spawns,owns,sticks,destroyed,reserved=0,true,0,0,0,0,{}
local world=node('World','Folder')
local character=node('Character','Model',world)
local function part(name,parent)
 local v=node(name,'Part',parent);v.CFrame=CFrame.new();v.Position=Vector3.zero;return v
end
local root=part('saviHRP',character)
local target=part('FirePlayerPart',root)
local humanoid=node('Humanoid','Humanoid',character);humanoid.Health=100;humanoid.RootPart=root
local inventory=node('Toys','Folder',world)
local context={
 Character=function()return character end,Root=function()return root end,
 Enabled=function()return enabled end,Clock=function()return now end,Ping=function()return .05 end,
 Inventory=function()return inventory end,IsInventoryModel=function(m)return m.Parent==inventory end,
 IsOwner=function()return true end,IsPhysicsOwner=function()return true end,
 Reserve=function(m,v)reserved[m]=v and true or nil end,
 Own=function()owns+=1 end,
 ApplyOffset=function(sticky,t)sticks+=1;sticky:FindFirstChild('StickyWeld').Part1=t end,
 Destroy=function(m)destroyed+=1;m.Parent=nil end,Notify=function()end,
 Spawn=function(id,frame,valid)
  spawns+=1;assert(valid())
  local m=node(id,'Model',inventory);m.CFrame=frame
  local sticky=part('StickyPart',m);part('SoundPart',m)
  local weld=node('StickyWeld','WeldConstraint',sticky);weld.Part0=sticky;weld.Enabled=true
  return m
 end,
}
local items=Items.Install(context);items:SetSpare(false);items:SetSprayWatch(false)
check('renamed saviHRP resolves the real protection hitbox',items:ResolveTarget()==target and items:_Root()==root)
items:Spawn(root);items:Update(now+.1)
check('spawn reaches a reserved real toy and acknowledged weld',spawns==1 and #items.Slots==1 and items:IsAttached(target)and reserved[items.ActiveModel])
for _=1,120 do now+=1/60;items:Maintain(root,target)end
check('attached guard is reused instead of spawning each update',spawns==1 and #items.Slots==1)
root.Name='realHrp'
check('realHrp is supported after in-place rename',items:ResolveTarget()==target)
local dummy=part('HumanoidRootPart',character)
check('dummy HumanoidRootPart does not hide the real hitbox',items:ResolveTarget()==target)
-- A stale root supplied by another controller must not reach a retired model.
local old=character;character=node('Respawn','Model',world)
local respawnRoot=part('HumanoidRootPart',character);local respawnTarget=part('RagdollTouchedHitbox',respawnRoot)
check('stale Context.Root is rejected after respawn',items:_Root()==respawnRoot and items:ResolveTarget()==respawnTarget)
root=respawnRoot;humanoid=node('Humanoid','Humanoid',character);humanoid.Health=100
items:Maintain(root,respawnTarget);items:Update(now+.1)
check('respawn discards the old toy and attaches a new one',spawns==2 and destroyed==1 and items:IsAttached(respawnTarget))
items:Dispose()
check('dispose clears reservations and destroys its own toys',#items.Slots==0 and next(reserved)==nil and items.Spawning==nil)
-- Missing hitboxes do not fall back to an arbitrary body weld.
respawnTarget.Parent=nil
local missing=Items.Install(context);local before=spawns
missing:Spawn(root)
check('missing native hitbox prevents an invalid spawn',spawns==before and #missing.Slots==0)
respawnTarget.Parent=root
-- Only one outstanding controller spawn, including while Spawn yields.
local originalSpawn=context.Spawn
context.Spawn=function(...)
 spawns+=1;coroutine.yield();return originalSpawn(...)
end
local pending=Items.Install(context);pending:SetSpare(false);pending:SetSprayWatch(false)
local co=coroutine.create(function()pending:Maintain(root,respawnTarget)end)
assert(coroutine.resume(co));local calls=spawns
pending:Maintain(root,respawnTarget)
check('yielding spawn remains single flight',spawns==calls and pending.Spawning~=nil)
enabled=false;pending:Reset(true)
local ok=coroutine.resume(co)
-- OriginalSpawn asserts the cancelled validity callback. No model is accepted.
check('disable during spawn releases its ticket without adopting',ok and pending.Spawning==nil and #pending.Slots==0)
enabled=true;context.Spawn=originalSpawn
local failure=Items.Install(context)
failure._Accept=function()error('incomplete replicated toy')end
failure:Maintain(root,respawnTarget)
check('setup error clears spawn ticket and reports the cause',failure.Spawning==nil and failure.LastReason:find('incomplete replicated toy',1,true)~=nil)
-- Run the actual Main startup/config synchronization, with the UI callbacks
-- deliberately suppressed just as the bundled library does during startup.
local settingsItems=Items.Install(context);local applied
local api={AntiKickItems=settingsItems,SetAntiKick=function(v)applied=v end}
installSync(api,{AKItemDropdown={Value='Katana'},AKPlacement={Value='Hand'},AKGuardCount={Value=2},AKRotationY={Value=45}},
 {AntiKick={Value=true},AKHotSpare={Value=false},AKReattachGuard={Value=false}})
api.SyncAntiKickSettings()
check('startup applies saved Anti Kick enable and selected item',applied==true and settingsItems.Selected=='Katana'and settingsItems.Placement=='Hand')
check('startup applies false toggle values, guard count and rotation',not settingsItems.SpareEnabled and not settingsItems.GuardEnabled and settingsItems.Guards==2 and settingsItems.Rotation.Y==45)
print('ANTI KICK CHECKS '..passed..' passed')
