-- Settings regressions: actual Find/NativePage/Restore, no substituted layout.
local checks=0
local function check(name,ok)assert(ok,name);checks+=1;print('PASS '..name)end
local function connection()return{Live=true,Disconnect=function(self)self.Live=false end}end
local pending={}
local pg=node('PlayerGui');local guiRoot=node('MenuGui','Folder',pg)
local menu=node('Menu',nil,guiRoot);local contents=node('TabContents','Folder',menu)
local settings=node('Settings',nil,contents);local record={Node=settings,Kind='panel'}
local picker=node('ColorPicker',nil,settings)
local originalMenuSize={Native=true};menu.Size=originalMenuSize
local originalPosition={Native=true};picker.Position=originalPosition
local skin=node('Skin',nil,guiRoot)
local clock=node('Clock',nil,menu)
local cellConnection,propertyConnection,iconConnection=connection(),connection(),connection()
local batchConnection=connection()
local status={SetText=function(self,t)self.Text=t end}
local style=setmetatable({Enabled=true,Context={PlayerGui=pg,Defer=function(fn)pending[#pending+1]=fn end},
 Menu=menu,Contents=contents,Current=record,Pages={record},Watches={},CellWatches={},
 Records={},Created={},Layer=skin,Status=status,Quick={Clock=clock,Owns=function()return false end},
 CellWork={Record=record,Connection=batchConnection},CellStyles={},PendingRepairs={},IconConnection=iconConnection},Shop)
style:Write(menu,'Size',{Compact=true},'shared')
style:Write(picker,'Position',{Forced=true},'page')
style.Watches[picker]={Position=propertyConnection};style.CellWatches[picker]=cellConnection
-- A repair already queued by the old page must become inert after restoration.
style:QueueRepair(picker,'Position',style.Records[picker])
style:Find()
check('entering Settings restores native bounds and color-picker position',menu.Size==originalMenuSize and picker.Position==originalPosition)
check('Settings stops cell work, icon polling and geometry observers',not batchConnection.Live and not iconConnection.Live and not cellConnection.Live and not propertyConnection.Live)
check('Settings hides skin and extra clock without hiding native content',not skin.Visible and not clock.Visible and settings.Visible)
local q=pending;pending={};for _,fn in ipairs(q)do fn()end
check('queued geometry repair cannot rewrite restored Settings',picker.Position==originalPosition and next(style.Records)==nil)
-- Native picker moves repeatedly; there are no maintained property observers.
for i=1,600 do
 picker.Position={NativeDrag=i};picker:GetPropertyChangedSignal('Position'):Fire()
 style:Find()
end
check('600 native picker updates do not restyle or repair the menu',style.LayoutPasses==nil and style.GridPasses==nil and style.GeometryRepairs==nil and menu.Size==originalMenuSize and picker.Position.NativeDrag==600)
-- Store images/ranks drive owned cards, preserving atlas data rather than star icons.
local shopPage=node('ToyShop',nil,contents);local shopHolder=node('Contents',nil,shopPage)
local shopGrid=node('Grid','UIGridLayout',shopHolder)
local function image(name,parent,asset,side)
 local v=node(name,'ImageLabel',parent);v.Image=asset;v.AbsoluteSize=Vector2.new(side,side)
 v.ImageRectOffset=Vector2.new(12,24);v.ImageRectSize=Vector2.new(48,48);v.ImageColor3='native tint';return v
end
local first=node('Train','ImageButton',shopHolder);first.LayoutOrder=10;first.Image='star';first.AbsoluteSize=Vector2.new(300,300)
local main=image('ItemImage',first,'train-image-from-live-shop',80)
local second=node('NinjaShuriken','ImageButton',shopHolder);second.LayoutOrder=20
image('Preview',second,'shuriken-image-from-live-shop',80)
local ownedPage=node('Toys',nil,contents);local holder=node('Contents',nil,ownedPage)
local grid=node('Grid','UIGridLayout',holder)
local shuriken=node('NinjaShuriken','ImageButton',holder);shuriken.LayoutOrder=0
local train=node('Train','ImageButton',holder);train.LayoutOrder=1
local cards=setmetatable({Pages={{Node=shopPage,Grid=shopGrid},{Node=ownedPage,Grid=grid}},
 Context={ResolveItem=function(v)return v.Name end,Catalog={Train='fallback-train',NinjaShuriken='fallback-shuriken'}},Records={},Created={}},Shop)
cards:CaptureStore()
local picture=cards:PictureFor(train)
check('owned item uses live Toy Shop image and exact atlas crop',picture.Image==main.Image and picture.Offset==main.ImageRectOffset and picture.Size==main.ImageRectSize)
check('large outer favorite-star hit surface is not used as thumbnail',cards:NativePicture(first).Image==main.Image)
local plan={Cell=30,Scale=1,Columns=10,Grid={W=310,H=193,X=0,Y=0},Gap=1}
cards.Plan=plan
-- Record geometry operations while running the real Grid path on each page.
cards.Rect=function()end
cards.Watch=function()end
cards.Write=function(_,v,k,value)v[k]=value end
cards.QueueCells=function(self,rec,cells,p,height)self.LastHeight=height end
local ownedRecord=cards.Pages[2];ownedRecord.List=holder;ownedRecord.Items=holder
cards:Grid(ownedRecord);local ownedHeight=cards.LastHeight
local shopRecord=cards.Pages[1];shopRecord.List=shopHolder;shopRecord.Items=shopHolder
cards:Grid(shopRecord)
check('owned grid follows Toy Shop order using LayoutOrder',train.LayoutOrder==1 and shuriken.LayoutOrder==2 and grid.SortOrder==Enum.SortOrder.LayoutOrder)
check('Your Toys and Toy Shop have identical thumbnail/caption cell dimensions',ownedHeight==cards.LastHeight and ownedHeight==44)
-- Test the real StyleCell thumbnail path with preallocated image instances.
local preview=node('Preview','ViewportFrame',train)
local native=image('Icon',train,'wrong-inventory-image',100)
local thumb=image('AstralShopThumbnail',train,'',30)
cards.CellStyles={};cards.DescCache=nil
cards:StyleCell(train,plan,44,false)
check('owned preview becomes the same fitted flat image as the shop',thumb.Image==main.Image and thumb.ImageRectOffset==main.ImageRectOffset and thumb.Size.X==30 and thumb.Size.Y==30)
check('hidden live 3D preview cannot cover or keep rendering the toy image',not preview.Visible and native.ImageTransparency==1)
print('SHOP REGRESSION CHECKS '..checks..' passed')
