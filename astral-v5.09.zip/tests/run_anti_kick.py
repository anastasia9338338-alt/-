from pathlib import Path
import os
import subprocess
root=Path(__file__).resolve().parents[1]
source=(root/'modules/Main.lua').read_text()
a=source.index('            tbl12.SyncAntiKickSettings=function()')
b=source.index('            lib:OnUnload(function()tbl12.AntiKickItems:Dispose()',a)
assert '    tbl12.SyncAntiKickSettings()'in source
assert 'if tbl12.SyncAntiKickSettings then tbl12.SyncAntiKickSettings()end'in source
parts=[(root/'tests/anti_kick_prelude.luau').read_text(),
 'local Items=(function()\n'+(root/'modules/AntiKickItems.lua').read_text()+'\nend)()',
 'local function installSync(tbl12,options,toggles)\n'+source[a:b]+'\nend',
 (root/'tests/anti_kick_body.luau').read_text()]
p=root/'tests/anti_kick.generated.luau';p.write_text('\n'.join(parts))
subprocess.run([os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau')),str(p)],check=True)
