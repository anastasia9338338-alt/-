-- Transform substitutes test controller flow, not Roblox physics.
local Vec={};Vec.__index=Vec
function Vec.__sub(a,b)return setmetatable({X=a.X-b.X,Y=a.Y-b.Y,Z=a.Z-b.Z,Magnitude=math.sqrt((a.X-b.X)^2+(a.Y-b.Y)^2+(a.Z-b.Z)^2)},Vec)end
Vector3={new=function(x,y,z)return setmetatable({X=x or 0,Y=y or 0,Z=z or 0},Vec)end}
Vector3.zero=Vector3.new()
local Frame={};Frame.__index=Frame
CFrame={new=function(x,y,z)return setmetatable({Position=Vector3.new(x,y,z)},Frame)end}
function CFrame.Angles()return CFrame.new()end
function Frame.__mul(a,b)return CFrame.new(a.Position.X+b.Position.X,a.Position.Y+b.Position.Y,a.Position.Z+b.Position.Z)end
function Frame.__add(a,b)return CFrame.new(a.Position.X+b.X,a.Position.Y+b.Y,a.Position.Z+b.Z)end
function Frame:ToObjectSpace()return CFrame.new()end
function Frame:Inverse()return CFrame.new()end
