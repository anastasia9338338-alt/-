local Vector3={}
local vector={};vector.__index=vector
function Vector3.new(x,y,z)return setmetatable({X=x or 0,Y=y or 0,Z=z or 0},vector)end
function vector.__add(a,b)return Vector3.new(a.X+b.X,a.Y+b.Y,a.Z+b.Z)end
function vector:Lerp(b,t)return Vector3.new(self.X+(b.X-self.X)*t,self.Y+(b.Y-self.Y)*t,self.Z+(b.Z-self.Z)*t)end
Vector3.zero=Vector3.new()
local CFrame={}
local frame={}
function CFrame.new(p)return setmetatable({Position=p or Vector3.zero},frame)end
function frame.__mul(a,b)return CFrame.new(a.Position+b.Position)end
local function signal()
    local self={Listeners={}}
    function self:Connect(callback)
        local c={Connected=true};function c:Disconnect()self.Connected=false end
        table.insert(self.Listeners,{Callback=callback,Connection=c});return c
    end
    function self:Fire(...)
        for _,v in ipairs(self.Listeners)do if v.Connection.Connected then v.Callback(...)end end
    end
    return self
end
local factories={}
local modules={}
local function requireModule(name)
    if not modules[name]then modules[name]=assert(factories[name],name)(requireModule)end
    return modules[name]
end
