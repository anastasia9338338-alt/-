-- Deterministic mock regression checks; no game/remotes are loaded.
Color3={fromRGB=function(...)return {...}end}
local Vector={};Vector.__index=Vector
function Vector.__div(v,n)return setmetatable({X=v.X/n,Y=v.Y/n},Vector)end
Vector2={new=function(x,y)return setmetatable({X=x,Y=y},Vector)end,zero=setmetatable({X=0,Y=0},Vector)}
UDim2={fromOffset=function(x,y)return{X=x,Y=y}end,fromScale=function(x,y)return{X=x,Y=y}end}
UDim={new=function(s,o)return{Scale=s,Offset=o}end}
Enum=setmetatable({},{__index=function(_,key)return setmetatable({},{__index=function(_,v)return key..'.'..v end})end})
Font={fromEnum=function(v)return v end}
local function signal()
 local s={Listeners={}}
 function s:Connect(fn)
  local c={Live=true,Fn=fn};function c:Disconnect()self.Live=false end
  self.Listeners[#self.Listeners+1]=c;return c
 end
 function s:Fire(...)for _,c in ipairs(self.Listeners)do if c.Live then c.Fn(...)end end end
 return s
end
local function node(name,kind,parent)
 local v={Name=name,Kind=kind or 'Frame',Parent=parent,Children={},Visible=true,AbsoluteSize=Vector2.new(600,400),AbsolutePosition=Vector2.zero,LayoutOrder=0,ZIndex=1,Image='',Text='',Changed=signal(),Signals={}}
 function v:IsA(class)return self.Kind==class or class=='GuiObject'and(self.Kind=='Frame'or self.Kind=='TextLabel'or self.Kind=='TextButton'or self.Kind=='ImageLabel'or self.Kind=='ImageButton'or self.Kind=='ScrollingFrame'or self.Kind=='ViewportFrame')end
 function v:IsDescendantOf(ancestor)local n=self.Parent;while n do if n==ancestor then return true end;n=n.Parent end;return false end
 function v:GetChildren()return self.Children end
 function v:FindFirstChild(name,recursive)for _,c in ipairs(self.Children)do if c.Name==name then return c end end;if recursive then for _,c in ipairs(self.Children)do local r=c:FindFirstChild(name,true);if r then return r end end end end
 function v:FindFirstChildWhichIsA(kind,recursive)
  for _,c in ipairs(self.Children)do if c:IsA(kind)then return c end end
  if recursive then for _,c in ipairs(self.Children)do local r=c:FindFirstChildWhichIsA(kind,true);if r then return r end end end
 end
 function v:FindFirstChildOfClass(kind)return self:FindFirstChildWhichIsA(kind)end
 function v:GetPropertyChangedSignal(key)if not self.Signals[key]then self.Signals[key]=signal()end;return self.Signals[key]end
 function v:Destroy()self.Parent=nil;self.Destroyed=true end
 if parent then table.insert(parent.Children,v)end
 return v
end
