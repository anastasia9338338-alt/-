from pathlib import Path
import subprocess
import os
import sys
root=Path(__file__).resolve().parents[1]
source=(root/'modules/Main.lua').read_text()
start=source.index('tbl12.SpawnToy = function(')
end=source.index('tbl12.DestroyToy = function(',start)
chunk=source[start:end].rstrip()
template=(root/'tests/spawn_toy_mocks.luau').read_text()
assert template.count('-- INSERT_ACTUAL_SPAWN_TOY')==1
out=root/'tests/.spawn_toy_generated.luau'
out.write_text(template.replace('-- INSERT_ACTUAL_SPAWN_TOY',chunk))
cli=os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau'))
result=subprocess.run([str(cli),str(out)],cwd=root)
sys.exit(result.returncode)
