local Loop=requireModule('KickLoop')
for _,mode in ipairs({'Faster','Normal','Super Fast'})do
    local now=0;local events={};local valid=true
    local ctx={Clock=function()return now end,SourceMode=function()return mode end,ShadowSource=true,
        KeepCapture=true,RecoverLostHold=true,
        Grab=function()events[#events+1]='G'end,Release=function()events[#events+1]='R'end}
    local loop=setmetatable({Context=ctx,Calls=0,Released=0,Valid=function()return valid end},Loop)
    -- The old source cycle does not wait for the v5.07 stable-hold gate or
    -- divert to its new recovery branch. These are regression inputs.
    local session={Root={},Humanoid={Sit=false},CaptureAcknowledged=true,HadPhysicalHold=false,RecoveringHold=true}
    for frame=1,60 do
        now=frame/60;loop.Frame=frame;loop:SourceCycle(session,now,nil,true)
    end
    assert(loop.Calls==60,'v5.06 must refresh every native tick')
    assert(loop.Released==(mode=='Normal'and 120 or 360),'restore the original six-release batches and source cadence')
    local n=#events;valid=false;loop:SourceCycle(session,now,nil,true)
    assert(#events==n,'invalidated targets must stop')
    print('PASS restored v5.06 source cadence',mode,loop.Calls,'grabs',loop.Released,'releases per 60 native ticks')
end
-- Import old defaults into the requested high-FPS profile; preserve new
-- choices and slower/custom settings that were explicitly selected.
do
    local Style=requireModule('UIStyle')
    local function config(mode,rate)
        local function option(value)
            return {Value=value,SetValue=function(self,v)self.Value=v end}
        end
        return {Options={AstralOwnershipMode=option(mode),AstralPalletContactRate=option(rate)}}
    end
    for _,version in ipairs({506,507})do
        local c=config('Faster',155)
        assert(Style.MigratePalletCadence(c,version))
        assert(c.Options.AstralOwnershipMode.Value=='Super Fast'and c.Options.AstralPalletContactRate.Value==155)
        c=config('Super Fast',155);Style.MigratePalletCadence(c,version)
        assert(c.Options.AstralOwnershipMode.Value=='Super Fast'and c.Options.AstralPalletContactRate.Value==155)
        c=config('Normal',90);Style.MigratePalletCadence(c,version)
        assert(c.Options.AstralOwnershipMode.Value=='Normal'and c.Options.AstralPalletContactRate.Value==90)
    end
    local c=config('Faster',155);assert(not Style.MigratePalletCadence(c,508))
    assert(c.Options.AstralOwnershipMode.Value=='Faster'and c.Options.AstralPalletContactRate.Value==155)
    print('PASS high-FPS speed defaults migration; Normal/custom rates and current-version choices preserved')
end

-- Construction/import suppresses callbacks in the actual UI library. The
-- real Main helper must apply mode AND rate without waiting for a UI click.
do
    local data={};local switches=0;local rate
    local api={PalletRagdoll={
        SetKickMode=function(_,value)assert(data.NKSourceMode==value);switches+=1 end,
        SetContactRate=function(_,value)rate=value end}}
    local options={AstralOwnershipMode={Value='Super Fast'},AstralPalletContactRate={Value=155}}
    installSettingsSync(api,data,options);api.SyncKickSettings()
    assert(data.NKSourceMode=='Super Fast'and rate==155 and switches==1)
    api.SyncKickSettings();assert(switches==1,'unchanged mode must not reset trajectories')
    options.AstralOwnershipMode.Value='Normal';options.AstralPalletContactRate.Value=90
    api.SyncKickSettings();assert(data.NKSourceMode=='Normal'and rate==90 and switches==2)
    print('PASS startup/config synchronization applies displayed mode and rate despite suppressed UI callbacks')
end
