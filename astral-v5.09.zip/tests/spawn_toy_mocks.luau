local function fixture(config)
    local now=0
    local timers={}
    local threads={}
    local failures={}
    local function resume(thread,...)
        local ok,kind,value=coroutine.resume(thread,...)
        assert(ok,tostring(kind))
        if coroutine.status(thread)=='dead'then return end
        if kind=='wait'then
            timers[#timers+1]={Thread=thread,At=now+math.max(value or 0,1e-8)}
        elseif kind=='signal'then
            value.Waiters[#value.Waiters+1]=thread
        else error('unsupported scheduler yield '..tostring(kind))end
    end
    local task={}
    function task.spawn(callback,...)
        local thread=coroutine.create(callback)
        threads[#threads+1]=thread
        resume(thread,...)
        return thread
    end
    function task.wait(duration)
        local began=now
        coroutine.yield('wait',duration or 0)
        return now-began
    end
    function task.delay(duration,callback)
        local thread=coroutine.create(callback)
        timers[#timers+1]={Thread=thread,At=now+duration}
        return thread
    end
    local function signal()
        local self={Listeners={},Waiters={}}
        function self:Connect(callback)
            local connection={Connected=true}
            function connection:Disconnect()self.Connected=false end
            self.Listeners[#self.Listeners+1]={Connection=connection,Callback=callback}
            return connection
        end
        function self:Fire(...)
            for _,listener in ipairs(self.Listeners)do
                if listener.Connection.Connected then listener.Callback(...)end
            end
            local waiters=self.Waiters;self.Waiters={}
            for _,thread in ipairs(waiters)do resume(thread,...)end
        end
        function self:Wait()return coroutine.yield('signal',self)end
        function self:Count()
            local count=0
            for _,listener in ipairs(self.Listeners)do if listener.Connection.Connected then count+=1 end end
            return count
        end
        return self
    end
    local os={clock=function()return now end}
    local vectorMT={}
    vectorMT.__add=function(a,b)return setmetatable({X=a.X+b.X,Y=a.Y+b.Y,Z=a.Z+b.Z},vectorMT)end
    local Vector3={}
    function Vector3.new(x,y,z)return setmetatable({X=x,Y=y,Z=z},vectorMT)end
    Vector3.zero=Vector3.new(0,0,0)
    local frameMT={}
    frameMT.__add=function(a,b)return setmetatable({Position=a.Position+b},frameMT)end
    local CFrame={}
    function CFrame.new(x,y,z)
        local position=type(x)=='table'and x or Vector3.new(x or 0,y or 0,z or 0)
        return setmetatable({Position=position},frameMT)
    end
    local Enum={RenderPriority={Camera={Value=200}}}
    local RunService={Heartbeat=signal(),Bindings={}}
    function RunService:BindToRenderStep(name,priority,callback)assert(not self.Bindings[name]);self.Bindings[name]=callback end
    function RunService:UnbindFromRenderStep(name)self.Bindings[name]=nil end
    local origin=CFrame.new(11,12,13)
    local root={Parent={},CFrame=origin}
    local flag11=false
    local valid=true
    local tbl7={FailedToys={},States={},SpawnQueue={},SpawnOrder=0,ToyAuraReserved={}}
    local inPlot={Value=config.Plot==true}
    local inOwnedPlot={Value=false}
    local localPlayer={CanSpawnToy={Value=config.CanSpawn~=false}}
    local workspace={FindFirstChild=function()return nil end}
    local v17={ChildAdded=signal()}
    local tbl12={Char=function()return {},root end}
    local calls,active,maximum={},0,0
    local tbl11={SpawnToy={}}
    function tbl11.SpawnToy:InvokeServer(name,frame,rotation)
        active+=1;maximum=math.max(maximum,active)
        calls[#calls+1]=now
        if config.RPCSeconds and config.RPCSeconds>0 then task.wait(config.RPCSeconds)end
        active-=1
        if config.RPCError then error('mock rpc error')end
        if config.Deliver then v17.ChildAdded:Fire({Name=name,Parent=v17})end
        return nil
    end
    local function warn(message)failures[#failures+1]=message end
    -- INSERT_ACTUAL_SPAWN_TOY
    local self={Data=tbl7,Service=RunService,Inventory=v17,Root=root,Origin=origin,Calls=calls,Errors=failures}
    function self:Cancel()valid=false end
    function self:Unload()flag11=true end
    function self:Permit()localPlayer.CanSpawnToy.Value=true end
    function self:Spawn(priority)
        self.Done=false
        return task.spawn(function()
            self.Result=tbl12.SpawnToy('PalletLightBrown',nil,priority or 1,true,function()return valid end)
            self.Done=true
        end)
    end
    function self:CallAgain()
        self.AgainDone=false
        return task.spawn(function()
            self.AgainResult=tbl12.SpawnToy('FoodCoconut',nil,1,true,function()return true end)
            self.AgainDone=true
        end)
    end
    function self:Step(dt)
        now+=dt
        local ready={}
        for i=#timers,1,-1 do
            if timers[i].At<=now then ready[#ready+1]=table.remove(timers,i).Thread end
        end
        for i=#ready,1,-1 do resume(ready[i])end
        RunService.Heartbeat:Fire(dt)
        for _,callback in pairs(RunService.Bindings)do callback()end
    end
    function self:Run(seconds)
        local finish=now+seconds
        while now<finish do self:Step(1/(config.FPS or 60))end
    end
    function self:Now()return now end
    function self:MaximumRPC()return maximum end
    function self:ActiveRPC()return active end
    function self:AssertClean()
        assert(not tbl7.States.Spawning and not tbl7.States.Owning,'locks not released')
        assert(#tbl7.SpawnQueue==0,'queue entry leaked')
        assert(next(RunService.Bindings)==nil,'render binding leaked')
        assert(RunService.Heartbeat:Count()==0 and v17.ChildAdded:Count()==0,'connections leaked')
        assert(root.CFrame==origin,'original pose not restored')
    end
    return self
end
-- Queued cancellation removes only its own queue entry, preserving another owner.
do
    local f=fixture({});f.Data.States.Spawning=true
    f:Spawn(2)
    assert(#f.Data.SpawnQueue==1)
    f:Cancel();f:Run(.1)
    assert(f.Done and #f.Data.SpawnQueue==0 and #f.Calls==0)
    assert(f.Data.States.Spawning==true,'queued caller released someone else lock')
    print('PASS SpawnToy queued cancellation')
end
-- Permission timeout must release both plot locks without acquiring connections.
do
    local f=fixture({Plot=true,CanSpawn=false})
    f:Spawn();f:Run(1.6)
    assert(f.Done and #f.Calls==0 and f:Now()>=1.5)
    f:AssertClean()
    print('PASS SpawnToy permission timeout releases locks')
end
-- RPC retries are bounded by time and each invocation must be single flight.
for _,fps in ipairs({30,60,144})do
 for _,rpcSeconds in ipairs({.02,.17})do
    local f=fixture({Plot=true,RPCSeconds=rpcSeconds,FPS=fps})
    f:Spawn();f:Run(1.6)
    assert(f.Done and #f.Calls>=2 and f:MaximumRPC()==1,'RPC concurrency')
    for i=2,#f.Calls do assert(f.Calls[i]-f.Calls[i-1]>=.1-1e-8,'RPC rate exceeded 10/sec')end
    f:AssertClean()
    print('PASS SpawnToy bounded plot requests',fps,'FPS',rpcSeconds,'RPC sec',#f.Calls,'requests')
 end
end
-- Both cancellation and unload stop further requests and restore hooks/pose.
for _,action in ipairs({'Cancel','Unload'})do
    local f=fixture({Plot=true,RPCSeconds=.04})
    f:Spawn();f:Run(.3);f[action](f);local count=#f.Calls;f:Run(.3)
    assert(f.Done and #f.Calls==count,'new request after '..action)
    f:AssertClean()
    print('PASS SpawnToy '..action..' stops requests and restores pose')
end
-- Remote failure must not strand ownership/spawn locks.
do
    local f=fixture({Plot=true,RPCError=true})
    f:Spawn();f:Run(1.5)
    assert(f.Done and string.find(f.Data.LastSpawnError,'mock rpc error',1,true))
    f:AssertClean()
    print('PASS SpawnToy RPC error releases locks')
end
-- Successful replication should return the model and reserve it for its caller.
do
    local f=fixture({Plot=true,Deliver=true,RPCSeconds=.04})
    f:Spawn();f:Run(.2)
    assert(f.Done and f.Result and f.Data.ToyAuraReserved[f.Result]==true)
    f:AssertClean()
    print('PASS SpawnToy replicated result and reservation')
end
-- Independent calls must not overlap a previously canceled in-flight RPC.
do
    local f=fixture({Plot=true,RPCSeconds=.6})
    f:Spawn();f:Run(.1);f:Cancel();f:Run(.05)
    assert(f.Done and f:ActiveRPC()==1)
    f:CallAgain();f:Run(2)
    assert(f.AgainDone and #f.Calls>=2,'following call never resumed')
    f:AssertClean()
    assert(f:MaximumRPC()==1,'canceled RPC overlapped a following SpawnToy call')
    print('PASS SpawnToy single flight across cancellation')
end
