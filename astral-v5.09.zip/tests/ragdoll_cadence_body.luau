local Pallet=requireModule('PalletRagdoll')
local Original=requireModule('OriginalPallet')
local Previous=requireModule('PreviousPallet')
local Bank=requireModule('PalletBank')
local Profile=requireModule('SuperFastProfile')
local function rig(p)
    p.Style=function()end;p.Restore=function()end
    local model={Parent={}}
    local sound={Parent=model,Anchored=false,IsA=function(_,class)return class=='BasePart'end,
        IsDescendantOf=function(_,parent)return parent==model end}
    p.Model,p.Sound=model,sound
    return model,sound
end
local function character(name)
    local c={Parent={},Name=name or 'target'}
    local root={Parent=c,Position=Vector3.new(1,2,3),Anchored=false,IsA=function(_,class)return class=='BasePart'end}
    local receiver={Parent=root,Name='RagdollTouchedHitbox',Position=Vector3.new(20,30,40),CanTouch=true,
        IsA=function(_,class)return class=='BasePart'end}
    function root:FindFirstChild(name)if name=='RagdollTouchedHitbox'then return receiver end end
    local hum={Parent=c,Health=100}
    function c:FindFirstChild(name)if name=='HumanoidRootPart'then return root end end
    function c:FindFirstChildOfClass(name)if name=='Humanoid'then return hum end end
    return c,root,receiver
end
local function harness(class,mode,hz,gate)
    local h={Now=0,Hz=hz or 60,Destroys=0,Releases=0}
    h.Pre,h.Post=signal(),signal()
    local context={RunService={PreSimulation=h.Pre,PostSimulation=h.Post},Clock=function()return h.Now end,
        Owned=function()return true end,Grab=function()end,SpawnThread=function()end,
        KickMode=function()return mode or 'Faster'end,ContactRate=(class==Original or class==Previous)and 155 or Profile.DefaultRate,CanContact=gate,
        ParkPosition=function()return Vector3.new(0,1000,0)end,
        Destroy=function()h.Destroys+=1 end,ReleaseSupply=function()h.Releases+=1 end,
        Find=function()end,Spawn=function()error('unexpected respawn')end}
    h.P=class.Install(context)
    if class==Bank then
        for _,worker in ipairs(h.P.Workers)do rig(worker)end
    else h.Model,h.Sound=rig(h.P)end
    function h:Tick()
        self.Now+=1/self.Hz;self.Pre:Fire(1/self.Hz);self.Post:Fire(1/self.Hz)
        if self.P.Workers then
            for _,w in ipairs(self.P.Workers)do assert(not w.LastError,w.LastError)end
        else assert(not self.P.LastError,self.P.LastError)end
    end
    function h:Run(seconds)for _=1,math.floor(seconds*self.Hz)do self:Tick()end end
    return h
end
-- Compare real v5.06 and current scheduling under the same solver callbacks.
for _,hz in ipairs({30,60,100,144,200,240,300})do
    for _,manual in ipairs({false,true})do
        local mode='Faster';local c=character()
        local old=harness(Original,mode,hz);old.P:Request(c,function()return true end,true,manual);old:Run(4)
        local new=harness(Pallet,mode,hz);new.P:Request(c,function()return true end,true,manual);new:Run(4)
        assert(new.P.SimulatedPlacements==math.floor(hz*4/2),'one contact per two solver callbacks at default rate')
        assert(new.P.SimulatedPlacements>old.P.SimulatedPlacements,'maintained contact path must actually run faster')
        assert(new.Destroys==0 and new.Releases==0,'continuous scheduling must not respawn a valid pallet')
        print('PASS ragdoll local placements',hz,'solver callbacks/s',manual and 'standalone loop'or 'during Kick',
            'v5.06',old.P.SimulatedPlacements/4,'/s; v5.08',new.P.SimulatedPlacements/4,'/s')
    end
end
-- Reproduce the actual v5.07 regression: its Main gate blocks a moving target
-- even though the pallet is owned and the request's lifetime is still valid.
do
    local c=character();local recovering=true;local close=false
    local loop={Sessions={[c]={Acquiring=false,RecoveringHold=true}}}
    function loop:IsPhysicallyHolding()return close end
    local players={GetPlayerFromCharacter=function(_,v)return v end}
    local gate=requireModule('PreviousGate')({KickLoop=loop},players)
    local previous=harness(Previous,'Super Fast',60,gate)
    previous.P:Request(c,function()return true end,true,false);previous:Run(4)
    assert(previous.P.SimulatedPlacements==0,'historical hard hold gate must reproduce the stall')
    local restored=harness(Pallet,'Faster',60)
    restored.P:Request(c,function()return true end,true,false);restored:Run(4)
    assert(restored.P.SimulatedPlacements==120,'restored contact scheduling must not depend on the hold-error/recovery gate')
    print('PASS reproduced v5.07 contact gate stall: 0 local placements; removed gate: 120 in 4 s')
end
-- No synthetic extra contacts from duplicate callbacks or zero simulation time.
do
    local h=harness(Pallet,'Faster',60);local c,root,receiver=character()
    h.P:Request(c,function()return true end,true,false)
    h.Pre:Fire();local attempts=h.P.StrikeAttempts
    assert(h.Sound.CFrame.Position.X==receiver.Position.X and h.Sound.CFrame.Position.Y==receiver.Position.Y)
    h.Pre:Fire();h.Post:Fire(0);h.Pre:Fire()
    assert(h.P.StrikeAttempts==attempts and h.P.SimulatedPlacements==0)
    h.Post:Fire(1/60);assert(h.P.SimulatedPlacements==1)
    h.Pre:Fire();assert(h.Sound.CFrame.Position.Y>1000,'an actual exit is required')
    h.Pre:Fire();assert(h.P.StrikeAttempts==attempts)
    h.Now+=1/60;h.Post:Fire(1/60);h.Pre:Fire();assert(h.P.StrikeAttempts==attempts+1)
    print('PASS contact/exit separation, real receiver and zero-time/duplicate-callback guards')
end
-- Respect a low requested rate; update it without a character restart.
do
    local h=harness(Pallet,'Faster',60);local c=character()
    h.P:SetContactRate(5);h.P:Request(c,function()return true end,true,true);h:Run(4)
    assert(h.P.SimulatedPlacements>=19 and h.P.SimulatedPlacements<=21)
    local count=h.P.SimulatedPlacements;h.P:SetContactRate(155);h:Run(4)
    assert(h.P.SimulatedPlacements-count>=119,'rate slider must apply to Faster continuous requests too')
    print('PASS rate changes affect maintained ragdoll in Faster')
end
-- Repeated source/manual requests share one entry and cannot exceed physics.
do
    local h=harness(Pallet,'Faster',60);local c=character();local lifetime=true
    local entry=h.P:Request(c,function()return lifetime end,true,false)
    for _=1,120 do
        assert(h.P:Request(c,nil,true,true)==entry);h:Tick()
    end
    assert(h.P.SimulatedPlacements==60)
    lifetime=false;h:Tick()
    assert(not h.P.Entries[c]and h.Destroys==1 and h.Releases==1)
    h.P:Cancel(c);assert(h.Destroys==1 and h.Releases==1)
    print('PASS repeated requests reuse entry; lifetime cancellation cleans up once')
end
-- Validate the requested 200-300 Hz range with the single actual worker.
for _,hz in ipairs({60,200,240,300})do
    for _,mode in ipairs({'Faster','Normal','Super Fast'})do
        local h=harness(Bank,mode,hz);local c=character()
        h.P:Request(c,function()return true end,true,false);h:Run(6)
        local count=0
        for _,w in ipairs(h.P.Workers)do count+=w.SimulatedPlacements end
        assert(#h.P.Workers==1,'exactly one pallet worker in every mode')
        local workers=1
        assert(count==workers*hz*6/2,'default cadence must use all available separate contact/exit frames')
        print('PASS bank LOCAL placements only',mode,hz,'solver callbacks/s',count/6,'/s;',count,'in 6 s; no server-kick assertion')
    end
end
-- A late callback cannot replay missed passes as a burst.
do
    local h=harness(Bank,'Super Fast',300);local c=character()
    h.P:Request(c,function()return true end,true,false);h:Run(.5)
    local before=0;for _,w in ipairs(h.P.Workers)do before+=w.SimulatedPlacements end
    h.Now+=.5;h.Pre:Fire(.5);h.Post:Fire(.5)
    local after=0;for _,w in ipairs(h.P.Workers)do after+=w.SimulatedPlacements end
    assert(#h.P.Workers==1 and after-before<=1,'one worker; no backlog replay across a hitch')
    print('PASS 500ms hitch does not replay contacts')
end
-- Preserve the original single-use trajectory and fair service to two targets.
do
    local h=harness(Pallet,'Normal',60);local c=character()
    local e=h.P:Request(c,function()return true end,false,false)
    local n,step,period=h.P:Profile(e);assert(n==8 and step==1/60 and period==0)
    h=harness(Pallet,'Faster',60)
    local a=h.P:Request(character('a'),function()return true end,true,false)
    local b=h.P:Request(character('b'),function()return true end,true,false)
    h:Run(4);assert(math.abs((a.SimulatedPlacements or 0)-(b.SimulatedPlacements or 0))<=1)
    assert((a.SimulatedPlacements or 0)+(b.SimulatedPlacements or 0)==120)
    print('PASS one-shot trajectory preserved and two-target queue remains fair')
end
