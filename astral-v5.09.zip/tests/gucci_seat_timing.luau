local Timing=require('../modules/GucciSeatTiming')
local function signal()
    local value={Listeners={}}
    function value:Connect(callback)
        local connection={Connected=true}
        function connection:Disconnect()self.Connected=false end
        self.Listeners[#self.Listeners+1]={Callback=callback,Connection=connection}
        return connection
    end
    function value:Fire(...)
        for _,listener in ipairs(self.Listeners)do
            if listener.Connection.Connected then listener.Callback(...)end
        end
    end
    function value:Count()
        local n=0
        for _,listener in ipairs(self.Listeners)do if listener.Connection.Connected then n+=1 end end
        return n
    end
    return value
end
for _,fps in ipairs({30,60,100,144,240})do
    local now=0
    local character={}
    local service={PreSimulation=signal(),PostSimulation=signal()}
    local root={Parent=character,CFrame=11,AssemblyLinearVelocity=3,AssemblyAngularVelocity=4}
    local seat={Parent={},ChildAdded=signal()}
    function seat:FindFirstChild()return self.Weld end
    local valid=true
    local detaches=0
    local guard=Timing.Start({Clock=function()return now end,RunService=service,Root=root,Seat=seat,Character=character,
        SettleSeconds=.15,Valid=function()return valid end,Detached=function()detaches+=1 end})
    local function weld(body)
        local value={Parent=seat,Name='SeatWeld',Part1=body}
        function value:IsA(name)return name=='Weld'end
        function value:Destroy()self.Parent=nil end
        return value
    end
    local stranger={IsDescendantOf=function()return false end}
    local foreign=weld(stranger)
    assert(not guard:TakeWeld(foreign))
    assert(foreign.Parent==seat and detaches==0,'must not consume another occupant weld')
    local candidate=weld(nil);seat.Weld=candidate
    seat.ChildAdded:Fire(candidate)
    assert(detaches==0,'uninitialized weld must wait for Part1')
    local body={IsDescendantOf=function(_,v)return v==character end}
    candidate.Part1=body
    service.PreSimulation:Fire(1/fps)
    assert(detaches==1 and candidate.Parent==nil,'physics rescan must consume completed local weld')
    root.CFrame=90000
    service.PostSimulation:Fire(1/fps)
    assert(root.CFrame==11,'must restore before replication after physics')
    assert(not guard:TakeWeld(candidate)and detaches==1,'ack exactly once')
    while not guard.Closed do
        now+=1/fps
        service.PreSimulation:Fire(1/fps)
        service.PostSimulation:Fire(1/fps)
        assert(now<1)
    end
    assert(now>=.15 and now<=.15+1/fps+.00001,'settle must use seconds')
    assert(service.PreSimulation:Count()==0 and service.PostSimulation:Count()==0 and seat.ChildAdded:Count()==0,'callbacks must be disconnected')
    print('PASS Gucci physics guard',fps,'FPS; settle seconds',now)
end
-- Cancellation before acknowledgement must not keep correcting the character.
do
    local service={PreSimulation=signal(),PostSimulation=signal()}
    local character={};local root={Parent=character,CFrame=1}
    local seat={Parent={},ChildAdded=signal(),FindFirstChild=function()end}
    local valid=true
    local guard=Timing.Start({Clock=function()return 0 end,RunService=service,Root=root,Seat=seat,Character=character,
        SettleSeconds=.15,Valid=function()return valid end,Detached=function()error('not expected')end})
    valid=false;root.CFrame=2;service.PreSimulation:Fire()
    assert(guard.Closed and root.CFrame==2)
    print('PASS Gucci cancellation releases physics guard')
end
-- Even when a native sit never acknowledges, pose guards must expire by time.
for _,fps in ipairs({30,60,144})do
    local now=0
    local service={PreSimulation=signal(),PostSimulation=signal()}
    local character={};local root={Parent=character,CFrame=1}
    local seat={Parent={},ChildAdded=signal(),FindFirstChild=function()end}
    local function start()
        return Timing.Start({Clock=function()return now end,RunService=service,Root=root,Seat=seat,Character=character,
            TimeoutSeconds=1,SettleSeconds=.15,Valid=function()return true end,Detached=function()error('not expected')end})
    end
    local guard=start()
    -- The integration disposes the previous guard before a retry starts.
    guard:Dispose();local replacement=start()
    assert(service.PreSimulation:Count()==1 and service.PostSimulation:Count()==1 and seat.ChildAdded:Count()==1)
    while not replacement.Closed do
        now+=1/fps
        if now>=1 then root.CFrame=2 end
        service.PreSimulation:Fire(1/fps)
        service.PostSimulation:Fire(1/fps)
        assert(now<1.1)
    end
    assert(now>=1 and now<=1+1/fps+.00001)
    assert(root.CFrame==2,'deadline must release pose without overwriting new motion')
    assert(service.PreSimulation:Count()==0 and service.PostSimulation:Count()==0 and seat.ChildAdded:Count()==0)
    print('PASS Gucci failed sit expires and retry leaves one guard',fps,'FPS')
end
