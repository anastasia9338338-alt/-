from pathlib import Path
import os
import subprocess
root=Path(__file__).resolve().parents[1]
parts=[(root/'tests/ragdoll_prelude.luau').read_text()]
for name in ('PalletOwnership','SuperFastProfile','PalletReaction','PalletRagdoll','PalletBank'):
    parts.append('factories.'+name+'=function(...)\n'+(root/'modules'/f'{name}.lua').read_text()+'\nend\n')
for name,file in [('OriginalPallet','PalletRagdoll.v5.06.lua'),('PreviousPallet','PalletRagdoll.v5.07.lua'),('PreviousGate','ContactGate.v5.07.lua')]:
    parts.append('factories.'+name+'=function(...)\n'+(root/'tests/fixtures'/file).read_text()+'\nend\n')
parts.append((root/'tests/ragdoll_cadence_body.luau').read_text())
p=root/'tests/ragdoll_cadence.generated.luau';p.write_text('\n'.join(parts))
subprocess.run([os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau')),str(p)],check=True)
