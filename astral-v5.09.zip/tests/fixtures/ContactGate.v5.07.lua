return function(tbl12,Players)
return function(character)
                        local loop=tbl12.KickLoop
                        if not loop then return true end
                        local player=Players:GetPlayerFromCharacter(character)
                        local session=player and loop.Sessions[player]
                        if not session then return true end
                        return not loop.Excursion and not loop.CaptureAnchor and not session.Acquiring
                            and not session.RecoveringHold and loop:IsPhysicallyHolding(player)
                    end
end
