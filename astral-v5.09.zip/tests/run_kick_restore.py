from pathlib import Path
import hashlib
import os
import subprocess

root=Path(__file__).resolve().parents[1]
expected_kick='a132fa090eddff4a96f6bdb04b239836251c8d1fa31264f7a25884a72fc776f0'
expected_install='6ac6377510a6e87ac8c3ecc173b6dc538fec358348b7e248fcc31c7744b29f3c'
assert hashlib.sha256((root/'modules/KickLoop.lua').read_bytes()).hexdigest()==expected_kick
main=(root/'modules/Main.lua').read_text()
a=main.index('            tbl12.KickLoop=requireModule("KickLoop").Install(')
end='            lib:OnUnload(function()tbl12.KickLoop:Dispose()end)'
b=main.index(end,a)+len(end)
assert hashlib.sha256(main[a:b].encode()).hexdigest()==expected_install
assert 'CanContact='not in main
assert 'Values={"Faster","Normal","Super Fast"},Default="Super Fast"'in main
print('PASS KickLoop and complete installation match measured v5.06 hashes; v5.07 contact gate removed',flush=True)
parts=['local factories={}\nlocal cache={}\nlocal function requireModule(name)\n if not cache[name]then cache[name]=factories[name](requireModule)end\n return cache[name]\nend\n']
for name in ('KickHandoff','SuperFastProfile','KickLoop','UIStyle'):
 parts.append('factories.'+name+'=function(...)\n'+(root/'modules'/f'{name}.lua').read_text()+'\nend\n')
a=main.index('        tbl12.SyncKickSettings=function()')
b=main.index('        local palletRateStatus=',a)
parts.append('local function installSettingsSync(tbl12,tbl9,options)\n'+main[a:b]+'\nend\n')
assert '    lib:FinishStartup()\n    tbl12.SyncKickSettings()'in main
assert 'if tbl12.SyncKickSettings then tbl12.SyncKickSettings()end'in main
parts.append((root/'tests/kick_restore_body.luau').read_text())
p=root/'tests/kick_restore.generated.luau';p.write_text('\n'.join(parts))
subprocess.run([os.environ.get('LUAU_BIN',str(root.parent/'tools/luau-0.747/luau')),str(p)],check=True)
